This version of Doctrine comes from https://github.com/Constellation/doctrine/commit/66ec67ccbf4aa59cb7b984c860f8b7cbce2770c4
